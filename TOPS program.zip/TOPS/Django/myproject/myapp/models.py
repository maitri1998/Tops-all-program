from django.db import models
from django.utils import timezone

# Create your models here.

class post(models.Model):
    title = models.CharField(max_length=150)
    content = models.TextField()
    published_at = models.DateTimeField(default=timezone.now)

    class meta:
        __name__ = 'posts'