// many Way to print on screen and console

// alert("Welcome Maitri");

// window.alert("Welcome Maitri");

// prompt("Enter your name :");

// window.prompt("Enter your name:");

// console.log("Welcome to python");

// console.dir("Welcome Maitri");

// console.warn("This is warning");

// console.error("This is error");

// let name = prompt("Enter your name :");
// console.log(`Welcome ${name}`);


// let name = prompt("Enter your name :");
// document.write(`Welcome ${name}`);

// to print string 
// let num1 = prompt("Enter first num :");
// let num2 = prompt("Enter second num :");
// let add = num1 + num2;
// document.write("Addition of numbers are : ",add);

// to print int we need to write parseInt
// let num1 = parseInt(prompt("Enter first num :"));
// let num2 = parseInt(prompt("Enter second num :"));
// let add = num1 + num2;
// document.write("Addition of numbers are : ",add);


function add(){
    let fn = document.getElementById('fn').value;
    let sn = document.getElementById('sn').value;

    let add = parseInt(fn)+parseInt(sn);
    //alert(`Addition is : ${add}`);
    document.write("Addition of numbers are : ",add)
}
function sub(){
    let fn = document.getElementById('fn').value;
    let sn = document.getElementById('sn').value;

    let sub = parseInt(fn)-parseInt(sn);
    //alert(`Addition is : ${add}`);
    document.write("Subtration of numbers are : ",sub)
}
function mul(){
    let fn = document.getElementById('fn').value;
    let sn = document.getElementById('sn').value;

    let mul = parseInt(fn)*parseInt(sn);
    //alert(`Addition is : ${add}`);
    document.write("Multiplication of numbers are : ",mul)
}
function div(){
    let fn = document.getElementById('fn').value;
    let sn = document.getElementById('sn').value;

    let div = parseInt(fn)/parseInt(sn);
    //alert(`Addition is : ${add}`);
    document.write("Division of numbers are : ",div)
}




