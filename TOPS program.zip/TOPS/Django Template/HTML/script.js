let form = document.getElementById('form');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;

    localStorage.setItem('username', username);
    localStorage.setItem('password', password);

    alert("Data Sucessfully Saved")

});


/*
Variable :
 1. let
 2. const
 3. Var
*/

// console.dir(document);
// console.log(document.URL);
// console.log(document.title);
// console.log(document.head);

// let hd = document.createElement('div');
// document.body.append(hd);
// console.log(hd);
// hd.textContent = "Welcome to Advanced Programing";
// hd.innerHTML ="<h1>Welcome to JavaScript Programming";
// hd.innerText = "Html and css programming";

// hd.textContent = "<h1> >Welcome to JavaScript Programming </h1>";
// hd.innerHTML ="<h1>Welcome to JavaScript Programming </h1>";
// hd.innerText = "<h1> >Welcome to JavaScript Programming  </h1>";

// hd.textContent = "Advanced javascript programming";

// hd.className ="box";
// hd.id = "mydiv";

// hd.style.color = "teal";
// hd.style.backgroundColor = "coral";
// hd.style.fontSize = "40px";

// let hd = document.getElementById('mydiv');
// console.log(hd);
// hd.innerHTML = "<h1> My div has been changed </h1>"

// let hd = document.querySelector('#mydiv');
// console.log(hd);
// hd.innerHTML = "This content has been changed"


// append and appendchild

// let div = document.createElement('div');
// append - String
// appendchild - string can't be passed

// document.body.appendChild(div);
// div.textContent = "Welcome to javascript";

// document.body.append(div);
// div.textContent = "Welcome to Append method";

// document.body.appendChild("Welcome");

// document.body.appendChild(hd);

// document.body.append("Welcome");

// document.body.append(hd);

// append : String, Element
// appendChild : element


for(let i=0;i<5;i++){
    let p = document.createElement('p');
    document.body.append(p);
    p.textContent = "Apple"+i;
}


