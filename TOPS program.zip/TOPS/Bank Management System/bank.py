class Bank:
    def __init__(self):
        self.customers = []

    def add_customer(self, customer):
        self.customers.append(customer)

    def view_customer(self, account_number):
        for customer in self.customers:
            if customer.account_number == account_number:
                print("Customer Details:")
                print("Account Number:", customer.account_number)
                print("Name:", customer.name)
                print("Balance:", customer.balance)
                print("Address:", customer.address)
                print("Phone Number:", customer.phone_number)
                break
        else:
            print("Customer does not exist.")

    def search_customer(self, customer_name):
        found = False
        for customer in self.customers:
            if customer.name == customer_name:
                print("Customer Details:")
                print("Account Number:", customer.account_number)
                print("Name:", customer.name)
                print("Balance:", customer.balance)
                print("Address:", customer.address)
                print("Phone Number:", customer.phone_number)
                found = True
        if not found:
            print("Customer not found.")

    def view_all_customers(self):
        for customer in self.customers:
            print("Customer Details:")
            print("Account Number:", customer.account_number)
            print("Name:", customer.name)
            print("Balance:", customer.balance)
            print("Address:", customer.address)
            print("Phone Number:", customer.phone_number)
            print()

    def total_amounts_in_bank(self):
        total_amount = 0
        for customer in self.customers:
            total_amount += customer.balance
        return total_amount

    def withdraw_amount(self, account_number, amount):
        for customer in self.customers:
            if customer.account_number == account_number:
                if customer.balance >= amount:
                    customer.balance -= amount
                    print("Withdrawal successful.")
                    print("New Balance:", customer.balance)
                else:
                    print("Insufficient balance for withdrawal.")
                break
        else:
            print("Customer does not exist.")

    def deposit_amount(self, account_number, amount):
        for customer in self.customers:
            if customer.account_number == account_number:
                customer.balance += amount
                print("Deposit successful.")
                print("New Balance:", customer.balance)
                break
        else:
            print("Customer does not exist.")

    def view_balance(self, account_number):
        for customer in self.customers:
            if customer.account_number == account_number:
                print("Account Number:", customer.account_number)
                print("Name:", customer.name)
                print("Balance:", customer.balance)
                break
        else:
            print("Customer does not exist.")

class Customer:
    def __init__(self, account_number, name, balance, address, phone_number):
        self.account_number = account_number
        self.name = name
        self.balance = balance
        self.address = address
        self.phone_number = phone_number

def main():
    bank = Bank()

    while True:
        print("WELCOME TO PYTHON BANK MANAGEMENT SYSTEM")
        print("Select your role:")
        print("1) Banker")
        print("2) Customer")
        print("3) Exit")
        choice = int(input("Choose your role: "))

        if choice == 1:
            # Banker operations
            while True:
                print("Operations Menu:")
                print("1) Add Customer")
                print("2) View Customer")
                print("3) Search Customer")
                print("4) View All Customers")
                print("5) Total Amounts in Bank")
                print("6) Exit")
                choice = int(input("Choose an operation: "))

                if choice == 1:
                    # Add customer
                    account_number = input("Enter account number: ")
                    name = input("Enter customer name: ")
                    balance = float(input("Enter initial balance: "))
                    address = input("Enter customer address: ")
                    phone_number = input("Enter customer phone number: ")
                    customer = Customer(account_number, name, balance, address, phone_number)
                    bank.add_customer(customer)
                elif choice == 2:
                    # View customer
                    account_number = input("Enter account number: ")
                    bank.view_customer(account_number)
                elif choice == 3:
                    # Search customer
                    customer_name = input("Enter customer name: ")
                    bank.search_customer(customer_name)
                elif choice == 4:
                    # View all customers
                    bank.view_all_customers()
                elif choice == 5:
                    # Total amounts in bank
                    total_amount = bank.total_amounts_in_bank()
                    print("Total amounts in bank:", total_amount)
                elif choice == 6:
                    # Exit
                    break
                else:
                    print("Invalid choice.")

        elif choice == 2:
            # Customer operations
            while True:
                print("Customer Operations Menu:")
                print("1) Withdraw Amount")
                print("2) Deposit Amount")
                print("3) View Balance")
                print("4) Exit")
                customer_choice = int(input("Choose an operation: "))

                if customer_choice == 1:
                    # Withdraw Amount
                    account_number = input("Enter your account number: ")
                    amount = float(input("Enter the withdrawal amount: "))
                    bank.withdraw_amount(account_number, amount)
                elif customer_choice == 2:
                    # Deposit Amount
                    account_number = input("Enter your account number: ")
                    amount = float(input("Enter the deposit amount: "))
                    bank.deposit_amount(account_number, amount)
                elif customer_choice == 3:
                    # View Balance
                    account_number = input("Enter your account number: ")
                    bank.view_balance(account_number)
                elif customer_choice == 4:
                    # Exit from customer operations
                    break
                else:
                    print("Invalid choice.")

        elif choice == 3:
            # Exit
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
