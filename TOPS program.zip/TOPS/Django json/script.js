// to fetch data from localstorage into textbox

let form = document.getElementById('form');
if (localStorage.getItem('username') && localStorage.getItem('password')){
    document.getElementById('username').value = localStorage.getItem('username');
    document.getElementById('password').value = localStorage.getItem('password');
}
form.addEventListener('login', (e)=> {
    e.preventDefault();
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;

    // local storage : json

    let user = {
        username : username,
        password : password
    }

    // setitem , getitem

    localStorage.setItem('user', JSON.stringify(user));

    console.log(JSON.stringify(user));

    alert("Login Sucessfully")
})

// to submit data from textbox to database 

if (localStorage.getItem('username') && localStorage.getItem('password')){
    document.getElementById('username').value = localStorage.getItem('username');
    document.getElementById('password').value = localStorage.getItem('password');
}

document.getElementById('login').addEventListener('click', (e)=>{
    e.preventDefault();
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;

    // local storage : json

    let user = {
        username : username,
        password : password
    }

    // setitem , getitem

    localStorage.setItem('user', JSON.stringify(user));

    console.log(JSON.stringify(user));

    alert("Login Sucessfully")
})



//clear data : clear button (it will clear form local storage)
document.getElementById('clear').addEventListener('click', (e)=>{
    localStorage.clear()
    console.clear()
    alert("Data Clear Sucessfully")
})